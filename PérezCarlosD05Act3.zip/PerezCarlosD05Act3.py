import os
import time
import re

nombres=[]
identificadores=[]
procesos=[]
lote=-1
contador=0
inicio=False
class Persona:
    def __init__(self, nombre, id, operacion, tiempo,resultado,lote):
        self.nombre=nombre
        self.id=id
        self.operacion=operacion
        self.tiempo=tiempo
        self.resultado=resultado
        self.lote=lote

def clearscreen():
    os.system('cls' if os.name == 'nt' else 'clear')

def declararProcesos():
    global nombres
    global identificadores
    global lote
    global procesos
    lotepersona=0
    while True:
        try:
            print("-----------------------------------------")
            print("--       Procesamiento por lotes       --")
            print("-----------------------------------------")
            numProcesos=int(input("Ingrese el número de procesos: "))
            if numProcesos>0:
                break
            else:
                print("Escribe un valor positivo")
        except:
            print("Ingrese un valor válido")
    for i in range(numProcesos):
        print("-----------------------------------------")
        print("--             Proceso {}              --".format(i+1))
        print("-----------------------------------------")
        while True:
            nombre=input("Nombre: ")
            if nombre in nombres:
                print("El nombre ya está registrado, ingrese de nuevo")
            elif not nombre.isalpha():
                print("El nombre debe ser solo con letras")
            else:
                nombres.append(nombre)
                break
        while True:
            try:
                identificador=int(input("ID: "))
                if identificador in identificadores:
                    print("El ID ya está registrado, ingrese de nuevo")
                else:
                    identificadores.append(identificador)
                    break
            except:
                print("El ID debe ser un número entero")
        while True:
            try:    
                op=input("Ingrese una operación +, -, /, *, %:\n")
                patronresta = re.compile(r'^(-?\d+)-(-?\d+)$')
                resultadoresta = patronresta.match(op)
                if op.count("*") == 1:
                    op2=op.split("*")
                    num1=float(op2[0])
                    num2=float(op2[1])
                    res=num1*num2
                    break
                elif op.count("+") == 1:
                    op2=op.split("+")
                    num1=float(op2[0])
                    num2=float(op2[1])
                    res=num1+num2
                    break
                elif op.count("/") == 1:
                    op2=op.split("/")
                    num1=float(op2[0])
                    num2=float(op2[1])
                    res=num1/num2
                    break
                elif op.count("%") == 1:
                    op2=op.split("%")
                    num1=float(op2[0])
                    num2=float(op2[1])
                    res=num1%num2
                    break
                elif resultadoresta:
                    num1 = int(resultadoresta.group(1))
                    num2 = int(resultadoresta.group(2))
                    res = num1 - num2
                    break
                else:
                    print("Operación inválida")
            except:
                print("Operación inválida")
        while True:
            try:
                tiempo=int(input("Tiempo: "))
                if tiempo > 0:
                   break 
                else:
                    print("Ingrese un valor positivo entero")       
            except:
                print("El ID debe ser un número entero")  
        
        if i%4==0: 
            lote += 1
            lotepersona+=1
        p = Persona(nombre, identificador, op, tiempo, res, lotepersona)
        procesos.append(p)
        print("Proceso guardado")
        input("Presione ENTER para continuar")
        clearscreen()

def contar(contador,tr,tt):
    
    time.sleep(1)
    contador+=1
    if tr==0:
        contador-=1
    tr-=1
    tt+=1
    clearscreen()
    return contador, tr, tt


loteEjecucion=[]
procesoEjecucion=[]
procesosTerminados=[]
def mostrarProcesos():
    global nombres
    global identificadores
    global lote
    global procesos
    global contador
    global inicio
    global loteEjecucion
    global procesoEjecucion
    global procesosTerminados
    siguiente=False
    tr=0
    tt=0
    linea=1
    for i in range(4):
        if len(procesos)==0:
            break
        else:
            obj=procesos.pop(0)
            loteEjecucion.append(obj)

    while True:
        clearscreen()
        print ("---------------------------------------------------------------------")
        print ("Lotes pendientes: ", lote)
        print ("Contador global: ", contador)
        print ("---------------------------------------------------------------------")
        print("                 Lote en ejecución\n")
        print("    ID   |   TME")
        for objeto in loteEjecucion:
            if siguiente:
                siguiente=False
                continue
            print(f"{objeto.id:6}   |{objeto.tiempo:6}")
        print ("---------------------------------------------------------------------")
        print("                 Proceso en ejecución\n")
        print("Nombre   |   Operación   |   TME    |    ID    |    TT     |     TR")
        if len(procesoEjecucion)==0 and len(loteEjecucion)>0:
            procsactual=loteEjecucion.pop(0)
            procesoEjecucion.append(procsactual)
            tr=procsactual.tiempo
            tt=0
            if inicio:
                print(f"{procsactual.nombre:8} |   {procsactual.operacion:11} |{procsactual.tiempo:6}    |{procsactual.id:6}    |{tt:6}     |  {tr:5}")
            if not inicio:
                inicio=True
        elif tr>=1:
            print(f"{procsactual.nombre:8} |   {procsactual.operacion:11} |{procsactual.tiempo:6}    |{procsactual.id:6}    |{tt:6}     |  {tr:5}")
        print()
        print ("---------------------------------------------------------------------")
        print("                 Procesos terminados\n")
        print("    ID   |   Operación   |   Resultado   |   Lote")
        if tr==0 and len(procesoEjecucion)>0:
            terminado=procesoEjecucion.pop(0)
            procesosTerminados.append(terminado)
            siguiente=True
        for terminados in procesosTerminados:
            print(f"  {terminados.id:5}  | {terminados.operacion:13} | {terminados.resultado:8}      | {terminados.lote:4}")
        print()
        print ("---------------------------------------------------------------------")
        if len(loteEjecucion)==0 and len(procesoEjecucion)==0:
            break
        contador, tr, tt=contar(contador,tr,tt)

def main():
    global procesos
    global lote
    global loteEjecucion
    global procesoEjecucion
    global inicio
    inicio = False
    clearscreen()
    declararProcesos()
    while True:
        if len(procesos)>0:
            loteEjecucion.clear()
            procesoEjecucion.clear()
            mostrarProcesos()
            lote-=1
        elif len(procesos)==0:
            input("Lotes procesados, pulse ENTER para salir")
            break
if __name__=='__main__':
    main()

