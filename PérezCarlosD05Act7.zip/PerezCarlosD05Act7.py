import os
import time
import random
import keyboard

numProcesos=0
procesosMax=0
procesos=[]
id=1
contador=0
inicio=False
memoria=0
e=False
w=False
p=False
c=False
class Persona:
    def __init__(self, id, operacion, tiempo,resultado, transcurrido, restante, llegada, finalizacion, servicio, espera, retorno, respuesta,bloqueado,bandera):
        self.id=id
        self.operacion=operacion
        self.tiempo=tiempo
        self.resultado=resultado
        self.transcurrido=transcurrido
        self.restante=restante
        self.llegada=llegada
        self.finalizacion=finalizacion
        self.servicio=servicio
        self.espera=espera
        self.retorno=retorno
        self.respuesta=respuesta
        self.bloqueado=bloqueado
        self.bandera=bandera

def clearscreen():
    os.system('cls' if os.name == 'nt' else 'clear')

def declararProcesos():
    global procesos
    global id
    global numProcesos
    global procesosMax
    while True:
            try:
                print("-----------------------------------------")
                print("--   Algoritmo de planificación FCFS   --")
                print("-----------------------------------------")
                numProcesos=int(input("Ingrese el número de procesos: "))
                if numProcesos>0:
                    break
                else:
                    print("Escribe un valor positivo")
            except:
                print("Ingrese un valor válido")
    procesosMax=numProcesos
    for _ in range(numProcesos):
        tiempo=random.randint(5,18)
        op1=random.randint(-100,100)
        op2=random.randint(1,100)
        op=random.randint(1,5)
        while True:
            try:
                if op == 1:
                    res=op1*op2
                    op = "{}*{}".format(op1,op2)
                    break
                elif op == 2:
                    res=op1+op2
                    op = "{}+{}".format(op1,op2)
                    break
                elif op == 3:
                    res=op1/op2
                    res=round(res,3)
                    op = "{}/{}".format(op1,op2)
                    break
                elif op == 4:
                    res=op1%op2
                    op = "{}%{}".format(op1,op2)
                    break
                elif op == 5:
                    res=op1-op2
                    op = "{}-{}".format(op1,op2)
                    break
                else:
                    print("Operación inválida")
            except:
                print("Operación inválida")
            
        p = Persona(id, op, tiempo, res, 0, tiempo, 0, 0, 0, 0, 0, 0,0,False)
        id+=1
        procesos.append(p)

listos=[]
procesoEjecucion=[]
procesosTerminados=[]
procesosBloqueados=[]

def on_key_press(tecla):
    global listos
    global procesosTerminados
    global procesoEjecucion
    global procesosBloqueados
    global contador
    global e
    global w
    global p
    global c
    global memoria
    if tecla.name == 'e' and len(procesoEjecucion)>0 and e==False and p==False:
        act=procesoEjecucion.pop(0)
        if act.transcurrido==act.tiempo or act.transcurrido+1>=act.tiempo:
            act.finalizacion=contador
            act.servicio=act.transcurrido
            procesosTerminados.append(act)
            memoria-=1
        else:
            procesosBloqueados.append(act)
            e=True
    if tecla.name == 'w' and len(procesoEjecucion)>0 and w==False and p==False:
        act=procesoEjecucion.pop(0)
        act.resultado="Error"
        act.finalizacion=contador
        act.servicio=act.transcurrido
        procesosTerminados.append(act)
        memoria-=1
        w=True
    if tecla.name == 'p' and len(procesoEjecucion)>0 and p==False:
        p=True
    if tecla.name == 'c' and len(procesoEjecucion)>0 and p==True:
        p=False

def contar(contador,tr,tt):
    
    time.sleep(1)
    contador+=1
    if tr==0:
        contador-=1
    tr-=1
    tt+=1
    clearscreen()
    return contador, tr, tt

def mostrarProcesos():
    global procesos
    global contador
    global inicio
    global e
    global w
    global numProcesos
    global memoria
    global procesosBloqueados
    for i in range(4):
        if len(procesos)==0:
            break
        else:
            obj=procesos.pop(0)
            obj.llegada=contador
            listos.append(obj)
            memoria += 1
    clearscreen()
    while True:
        if memoria != 4 and len(procesos)>0:
            obj=procesos.pop(0)
            obj.llegada=contador
            listos.append(obj)
            memoria += 1
        e=False
        w=False
        print ("---------------------------------------------------------------------")
        print ("Nuevos: ", len(procesos))
        print ("Contador global: ", contador)
        print ("---------------------------------------------------------------------")
        print("                         Listos\n")
        print("    ID   |   TME   |   TT")
        keyboard.on_press(on_key_press)
        i = 0
        while i < len(procesosBloqueados):
            if procesosBloqueados[i].bloqueado == 8:
                procBloq = procesosBloqueados.pop(i)
                procBloq.bloqueado = 0
                listos.append(procBloq)
            else:
                i += 1
        if len(procesoEjecucion)==0 and len(listos)>0:
            procsactual=listos.pop(0)
            if procsactual.bandera==False:
                procsactual.bandera=True
                procsactual.respuesta=contador-procsactual.llegada
            procesoEjecucion.append(procsactual)
        for i in range (len(listos)):
            print(f"{listos[i].id:6}   |{listos[i].tiempo:6}   |{listos[i].transcurrido:4}")
        print ("---------------------------------------------------------------------")
        print("                 Proceso en ejecución\n")
        print("Operación   |   TME    |    ID    |    TT     |     TR")
        if len(procesosTerminados)==numProcesos or len(procesosBloqueados)==4:
            print("")
        elif procsactual.restante>=1:
            print(f"{procsactual.operacion:11} |{procsactual.tiempo:6}    |{procsactual.id:6}    |{procsactual.transcurrido:6}     |  {procsactual.restante:5}")
        print()
        print ("---------------------------------------------------------------------")
        print("                 Procesos bloqueados\n")
        print("    ID   |   TTenB")
        for bloqueados in procesosBloqueados:
            if not p:
                bloqueados.bloqueado+=1
            print(f"{bloqueados.id:5}    |{bloqueados.bloqueado:6}")
        print()
        print ("---------------------------------------------------------------------")
        print("                 Procesos terminados\n")
        print("    ID   |   Operación   |   Resultado")
        if (procsactual.restante==0 and len(procesoEjecucion)>0):
            terminado=procesoEjecucion.pop(0)
            terminado.finalizacion=contador
            terminado.servicio=terminado.transcurrido
            procesosTerminados.append(terminado)
            memoria-=1
        
        for terminados in procesosTerminados:
            print(f"  {terminados.id:5}  | {terminados.operacion:13} | {terminados.resultado:8}")
        print()
        print ("---------------------------------------------------------------------")
        if len(procesos)==0 and len(procesoEjecucion)==0 and len(procesosBloqueados)==0 and len(listos)==0:
            break
        if p:
            print("Procesos en Pausa...")
            time.sleep(1)
            clearscreen()
            continue
        contador, procsactual.restante, procsactual.transcurrido=contar(contador,procsactual.restante,procsactual.transcurrido)

def mostrartabla():
    procesosTerminadosOrd= sorted(procesosTerminados, key=lambda x: x.id)
    print ("--------------------------------------------------------------------------------------------------------------------------------------")
    print("                                                     Tabla de procesos\n")
    print("    ID   |   Operación   |   TME   |   TLlegada   |   TFin   | TServicio   |   TEspera   |   TRetorno   |   TRespuesta   |   Resultado")
    for terminados in procesosTerminadosOrd:
        terminados.retorno = terminados.finalizacion - terminados.llegada
        terminados.espera = terminados.retorno - terminados.servicio
        print(f"  {terminados.id:5}  | {terminados.operacion:13} | {terminados.tiempo:5}   | {terminados.llegada:5}        | {terminados.finalizacion:5}    | {terminados.servicio:6}      | {terminados.espera:6}      | {terminados.retorno:6}       | {terminados.respuesta:7}        | {terminados.resultado:9}")
    print()

    print ("--------------------------------------------------------------------------------------------------------------------------------------")

def main():
    global procesos
    global inicio
    inicio = False
    clearscreen()
    declararProcesos()
    mostrarProcesos()
    clearscreen()
    mostrartabla()
    print("\nPulse ENTER para salir")
    print("\n")
    input()

if __name__=='__main__':
    main()