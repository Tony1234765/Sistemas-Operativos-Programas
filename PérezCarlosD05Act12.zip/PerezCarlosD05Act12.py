import os
import time
import random
import keyboard

numProcesos=0
procesosMax=0
procesos=[]
id=1
contador=0
inicio=False
memoria=0
e=False
w=False
p=False
c=False
n=False
b=False
quan=0
class Persona:
    def __init__(self, id, operacion, tiempo,resultado, restante,bandera):
        self.id=id
        self.operacion=operacion
        self.tiempo=tiempo
        self.resultado=resultado
        self.transcurrido=0
        self.restante=restante
        self.llegada="N/A"
        self.finalizacion="N/A"
        self.servicio=0
        self.espera=0
        self.retorno="N/A"
        self.respuesta="N/A"
        self.bloqueado=0
        self.bandera=bandera
        self.res2="N/A"
        self.listo=False
        self.terminado=False
        self.bloqueo=False
        self.nuevo=True
        self.ejecucion=False
        self.quantum=0
def clearscreen():
    os.system('cls' if os.name == 'nt' else 'clear')

def declararProcesos():
    global procesos
    global id
    global numProcesos
    global procesosMax
    global quan
    while True:
        try:
            print("-----------------------------------------")
            print("--   Algoritmo de planificación RR     --")
            print("-----------------------------------------")
            numProcesos=int(input("Ingrese el número de procesos: "))
            if numProcesos>0:
                break
            else:
                print("Escribe un valor positivo")
        except:
            print("Ingrese un valor válido")
    while True:
        try:
            quan=int(input("Ingrese el valor del quantum: "))
            if quan>0:
                break
            else:
                print("Escribe un valor positivo")
        except:
            print("Ingrese un valor válido")
    procesosMax=numProcesos
    for _ in range(numProcesos):
        tiempo=random.randint(5,18)
        op1=random.randint(-100,100)
        op2=random.randint(1,100)
        op=random.randint(1,5)
        while True:
            try:
                if op == 1:
                    res=op1*op2
                    op = "{}*{}".format(op1,op2)
                    break
                elif op == 2:
                    res=op1+op2
                    op = "{}+{}".format(op1,op2)
                    break
                elif op == 3:
                    res=op1/op2
                    res=round(res,3)
                    op = "{}/{}".format(op1,op2)
                    break
                elif op == 4:
                    res=op1%op2
                    op = "{}%{}".format(op1,op2)
                    break
                elif op == 5:
                    res=op1-op2
                    op = "{}-{}".format(op1,op2)
                    break
                else:
                    print("Operación inválida")
            except:
                print("Operación inválida")
            
        p = Persona(id, op, tiempo, res, tiempo,False)
        id+=1
        procesos.append(p)

def agregarProceso():
    global procesos
    global id
    global numProcesos
    numProcesos+=1
    tiempo=random.randint(5,18)
    op1=random.randint(-100,100)
    op2=random.randint(1,100)
    op=random.randint(1,5)
    if op == 1:
        res=op1*op2
        op = "{}*{}".format(op1,op2)
    elif op == 2:
        res=op1+op2
        op = "{}+{}".format(op1,op2)
    elif op == 3:
        res=op1/op2
        res=round(res,3)
        op = "{}/{}".format(op1,op2)
    elif op == 4:
        res=op1%op2
        op = "{}%{}".format(op1,op2)
    elif op == 5:
        res=op1-op2
        op = "{}-{}".format(op1,op2)
    else:
        print("Operación inválida")     
    p = Persona(id, op, tiempo, res, tiempo,False)
    id+=1
    procesos.append(p)

listos=[]
procesoEjecucion=[]
procesosTerminados=[]
procesosBloqueados=[]

def tablaProcesos():
    procesosTotales=[]
    procesosTotales=procesos + listos + procesoEjecucion + procesosTerminados + procesosBloqueados
    procesosTotalesOrd= sorted(procesosTotales, key=lambda x: x.id)
    print ("--------------------------------------------------------------------------------------------------------------------------------------")
    print("                                                     Tabla de procesos\n")
    print("    ID   |   Operación   |   TME   |   TLlegada   |   TFin   | TServicio   |   TEspera   |   TRetorno   |   TRespuesta   |   Resultado   |   TBloqueado   |   Estado")
    for process in procesosTotalesOrd:
        if process.ejecucion:
            process.servicio=process.transcurrido
            process.espera=contador-process.llegada-process.servicio
            print(f"  {process.id:5}  | {process.operacion:13} | {process.tiempo:5}   | {process.llegada:5}        | {process.finalizacion:5}    | {process.servicio:6}      | {process.espera:6}      | {process.retorno:6}       | {process.respuesta:7}        |     {process.res2:9} |    {"N/A":9}   |   Ejecutándose")
        elif process.listo:
            process.servicio=process.transcurrido
            process.espera=contador-process.llegada-process.servicio
            print(f"  {process.id:5}  | {process.operacion:13} | {process.tiempo:5}   | {process.llegada:5}        | {process.finalizacion:5}    | {process.servicio:6}      | {process.espera:6}      | {process.retorno:6}       | {process.respuesta:7}        |     {process.res2:9} |    {"N/A":9}   |   Listo")
        elif process.nuevo:
            print(f"  {process.id:5}  | {"N/A":13} | {"N/A":5}   | {"N/A":5}        | {"N/A":5}    | {"N/A":6}      | {"N/A":6}      | {"N/A":6}       | {"N/A":7}        |     {"N/A":9} |    {"N/A":9}   |   Nuevo")
        elif process.bloqueado:
            process.servicio=process.transcurrido
            process.espera=contador-process.llegada-process.servicio
            print(f"  {process.id:5}  | {process.operacion:13} | {process.tiempo:5}   | {process.llegada:5}        | {process.finalizacion:5}    | {process.servicio:6}      | {process.espera:6}      | {process.retorno:6}       | {process.respuesta:7}        |     {process.res2:9} |    {process.bloqueado:3}         |   Bloqueado")
        elif process.terminado:
            process.retorno = process.finalizacion - process.llegada
            process.espera = process.retorno - process.servicio
            print(f"  {process.id:5}  | {process.operacion:13} | {process.tiempo:5}   | {process.llegada:5}        | {process.finalizacion:5}    | {process.servicio:6}      | {process.espera:6}      | {process.retorno:6}       | {process.respuesta:7}        | {process.resultado:9}     |    {"N/A":9}   |   Terminado")
        
    print()
    print ("--------------------------------------------------------------------------------------------------------------------------------------")


def on_key_press(tecla):
    global listos
    global procesosTerminados
    global procesoEjecucion
    global procesosBloqueados
    global contador
    global e
    global w
    global p
    global c
    global n
    global b
    global memoria
    if tecla.name == 'e' and len(procesoEjecucion)>0 and e==False and p==False:
        act=procesoEjecucion.pop(0)
        if act.transcurrido==act.tiempo or act.transcurrido+1>=act.tiempo:
            act.finalizacion=contador
            act.servicio=act.transcurrido
            act.terminado=True
            act.listo=False
            act.ejecucion=False
            procesosTerminados.append(act)
            memoria-=1
        else:
            contador-=1
            act.quantum=0
            procesosBloqueados.append(act)
            act.bloqueo=True
            act.ejecucion=False
            act.listo=False
            listos[0].quantum+=1
            e=True
    if tecla.name == 'w' and len(procesoEjecucion)>0 and w==False and p==False:
        act=procesoEjecucion.pop(0)
        act.resultado="Error"
        act.finalizacion=contador
        act.servicio=act.transcurrido
        act.terminado=True
        act.ejecucion=False
        act.listo=False
        procesosTerminados.append(act)
        memoria-=1
        w=True
    if tecla.name == 'p' and (procesoEjecucion or procesosBloqueados) and p==False:
        p=True

    if tecla.name == 'c' and (procesoEjecucion or procesosBloqueados) and p==True:
        p=False
        b=False
        clearscreen()

    if tecla.name == 'n' and (procesoEjecucion or procesosBloqueados) and n==False and p==False:
        agregarProceso()
        n=True
    
    if tecla.name == 'b' and (procesoEjecucion or procesosBloqueados) and b==False and p==False:
        b=True
        p=True


def contar(contador,tr,tt):
    
    time.sleep(1)
    contador+=1
    tr-=1
    tt+=1
    return contador, tr, tt

def mostrarProcesos():
    global procesos
    global contador
    global inicio
    global e
    global w
    global n
    global numProcesos
    global memoria
    global procesosBloqueados
    global listos
    global quan
    for i in range(4):
        if len(procesos)==0:
            break
        else:
            obj=procesos.pop(0)
            obj.listo=True
            obj.nuevo=False
            obj.llegada=contador
            listos.append(obj)
            memoria += 1
    clearscreen()
    while True:
        e=False
        w=False
        n=False
        if p and b:
            clearscreen()
            tablaProcesos()
            time.sleep(1)
            continue
        elif not b:
            if memoria != 4 and len(procesos)>0:
                obj=procesos.pop(0)
                obj.nuevo=False
                obj.listo=True
                obj.llegada=contador
                listos.append(obj)
                memoria += 1
            print ("---------------------------------------------------------------------")
            print ("Nuevos: ", len(procesos))
            print ("Contador global: ", contador)
            print ("Valor del Quantum: ", quan)
            print ("---------------------------------------------------------------------")
            print("                         Listos\n")
            print("    ID   |   TME   |   TT")
            keyboard.on_press(on_key_press)
            i = 0
            while i < len(procesosBloqueados):
                if procesosBloqueados[i].bloqueado == 8:
                    procBloq = procesosBloqueados.pop(i)
                    procBloq.bloqueado = 0
                    procBloq.bloqueo=False
                    procBloq.listo=True
                    listos.append(procBloq)
                else:
                    i += 1
            if len(procesoEjecucion)==0 and len(listos)>0:
                procsactual=listos.pop(0)
                if procsactual.bandera==False:
                    procsactual.bandera=True
                    procsactual.respuesta=contador-procsactual.llegada
                procsactual.ejecucion=True
                procesoEjecucion.append(procsactual)
            for i in range (len(listos)):
                print(f"{listos[i].id:6}   |{listos[i].tiempo:6}   |{listos[i].transcurrido:4}")
            print ("---------------------------------------------------------------------")
            print("                 Proceso en ejecución\n")
            print("Operación   |   TME    |    ID    |    TT     |     TR   |   Quantum")
            if len(procesosTerminados)==numProcesos or len(procesosBloqueados)==4:
                print("")
            elif procsactual.restante>=1 and procesoEjecucion and procsactual.ejecucion:
                print(f"{procsactual.operacion:11} |{procsactual.tiempo:6}    |{procsactual.id:6}    |{procsactual.transcurrido:6}     |  {procsactual.restante:5}   |  {procsactual.quantum:5}")
            print()
            if (procsactual.quantum==quan and procsactual.restante!=0):
                procsactual.quantum=0
                procsactual.ejecucion=False
                paso=procesoEjecucion.pop(0)
                listos.append(paso)
            print ("---------------------------------------------------------------------")
            print("                 Procesos bloqueados\n")
            print("    ID   |   TTenB")
            for bloqueados in procesosBloqueados:
                if not p:
                    bloqueados.bloqueado+=1
                print(f"{bloqueados.id:5}    |{bloqueados.bloqueado:6}")
            print()
            print ("---------------------------------------------------------------------")
            print("                 Procesos terminados\n")
            print("    ID   |   Operación   |   Resultado")
            if (procsactual.restante==0 and len(procesoEjecucion)>0):
                terminado=procesoEjecucion.pop(0)
                terminado.finalizacion=contador
                terminado.servicio=terminado.transcurrido
                terminado.terminado=True
                terminado.listo=False
                terminado.ejecucion=False
                procesosTerminados.append(terminado)
                memoria-=1
            
            for terminados in procesosTerminados:
                print(f"  {terminados.id:5}  | {terminados.operacion:13} | {terminados.resultado:8}")
            print()
            print ("---------------------------------------------------------------------")
            if len(procesos)==0 and len(procesoEjecucion)==0 and len(procesosBloqueados)==0 and len(listos)==0:
                break
            if p:
                print("Procesos en Pausa...")
                time.sleep(1)
                clearscreen()
                continue
            if procesosBloqueados or procesoEjecucion:
                contador, procsactual.restante, procsactual.transcurrido=contar(contador,procsactual.restante,procsactual.transcurrido)
                procsactual.quantum+=1
            clearscreen()
        

def mostrartabla():
    procesosTerminadosOrd= sorted(procesosTerminados, key=lambda x: x.id)
    print ("--------------------------------------------------------------------------------------------------------------------------------------")
    print("                                                     Tabla de procesos\n")
    print("    ID   |   Operación   |   TME   |   TLlegada   |   TFin   | TServicio   |   TEspera   |   TRetorno   |   TRespuesta   |   Resultado")
    for terminados in procesosTerminadosOrd:
        terminados.retorno = terminados.finalizacion - terminados.llegada
        terminados.espera = terminados.retorno - terminados.servicio
        print(f"  {terminados.id:5}  | {terminados.operacion:13} | {terminados.tiempo:5}   | {terminados.llegada:5}        | {terminados.finalizacion:5}    | {terminados.servicio:6}      | {terminados.espera:6}      | {terminados.retorno:6}       | {terminados.respuesta:7}        | {terminados.resultado:9}")
    print()

    print ("--------------------------------------------------------------------------------------------------------------------------------------")

def main():
    global procesos
    global inicio
    inicio = False
    clearscreen()
    declararProcesos()
    mostrarProcesos()
    clearscreen()
    mostrartabla()
    print("\nPulse ENTER para salir")
    print("\n")
    input()

if __name__=='__main__':
    main()