import os
import time
import random
import keyboard

numProcesos=0
procesos=[]
id=1
lote=-1
contador=0
inicio=False
e=False
w=False
p=False
c=False
class Persona:
    def __init__(self, id, operacion, tiempo,resultado,lote, transcurrido, restante):
        self.id=id
        self.operacion=operacion
        self.tiempo=tiempo
        self.resultado=resultado
        self.lote=lote
        self.transcurrido=transcurrido
        self.restante=restante

def clearscreen():
    os.system('cls' if os.name == 'nt' else 'clear')

def declararProcesos():
    global lote
    global procesos
    global id
    global numProcesos
    lotepersona=0
    tt=0
    while True:
        try:
            print("-----------------------------------------")
            print("--       Procesamiento por lotes       --")
            print("-----------------------------------------")
            numProcesos=int(input("Ingrese el número de procesos: "))
            if numProcesos>0:
                break
            else:
                print("Escribe un valor positivo")
        except:
            print("Ingrese un valor válido")
    for i in range(numProcesos):
        tiempo=random.randint(5,18)
        op1=random.randint(-100,100)
        op2=random.randint(1,100)
        op=random.randint(1,5)
        while True:
            try:
                if op == 1:
                    res=op1*op2
                    op = "{}*{}".format(op1,op2)
                    break
                elif op == 2:
                    res=op1+op2
                    op = "{}+{}".format(op1,op2)
                    break
                elif op == 3:
                    res=op1/op2
                    res=round(res,3)
                    op = "{}/{}".format(op1,op2)
                    break
                elif op == 4:
                    res=op1%op2
                    op = "{}%{}".format(op1,op2)
                    break
                elif op == 5:
                    res=op1-op2
                    op = "{}-{}".format(op1,op2)
                    break
                else:
                    print("Operación inválida")
            except:
                print("Operación inválida")
        if i%4==0: 
            lote += 1
            lotepersona+=1
        p = Persona(id, op, tiempo, res, lotepersona,tt, tiempo)
        id+=1
        procesos.append(p)

def contar(contador,tr,tt):
    
    time.sleep(1)
    contador+=1
    if tr==0:
        contador-=1
    tr-=1
    tt+=1
    clearscreen()
    return contador, tr, tt


loteEjecucion=[]
procesoEjecucion=[]
procesosTerminados=[]
copialotes=[]
def on_key_press(tecla):
    global loteEjecucion
    global procesosTerminados
    global procesoEjecucion
    global e
    global w
    global p
    global c
    global copialotes
    if tecla.name == 'e' and len(procesoEjecucion)>0 and e==False and p==False:
        act=procesoEjecucion.pop(0)
        loteEjecucion.append(act)
        copialotes=loteEjecucion[:]
        e=True
    if tecla.name == 'w' and len(procesoEjecucion)>0 and w==False and p==False:
        act=procesoEjecucion.pop(0)
        act.resultado="Error"
        procesosTerminados.append(act)
        copialotes=loteEjecucion[:]
        w=True
    if tecla.name == 'p' and len(procesoEjecucion)>0 and p==False:
        p=True
    if tecla.name == 'c' and len(procesoEjecucion)>0 and p==True:
        p=False

def mostrarProcesos():
    global lote
    global procesos
    global contador
    global inicio
    global loteEjecucion
    global procesoEjecucion
    global procesosTerminados
    global e
    global w
    global copialotes
    global numProcesos
    mostrar=True
    #siguiente=False
    for i in range(4):
        if len(procesos)==0:
            break
        else:
            obj=procesos.pop(0)
            loteEjecucion.append(obj)
    copialotes=loteEjecucion[:]
    clearscreen()
    
    while True:
        e=False
        w=False
        print ("---------------------------------------------------------------------")
        print ("Lotes pendientes: ", lote)
        print ("Contador global: ", contador)
        print ("---------------------------------------------------------------------")
        print("                 Lote en ejecución\n")
        print("    ID   |   TME   |   TT")
        keyboard.on_press(on_key_press)
        for i in range (1, len(copialotes)):
            if mostrar:
                print(f"{copialotes[i-1].id:6}   |{copialotes[i-1].tiempo:6}   |{copialotes[i-1].transcurrido:4}")
                mostrar=False
            #if siguiente:
                #siguiente=False
                #continue
            print(f"{copialotes[i].id:6}   |{copialotes[i].tiempo:6}   |{copialotes[i].transcurrido:4}")
        print ("---------------------------------------------------------------------")
        print("                 Proceso en ejecución\n")
        print("Operación   |   TME    |    ID    |    TT     |     TR")
        if len(procesosTerminados)==numProcesos:
            print("")
        elif len(procesoEjecucion)==0 and len(loteEjecucion)>0:
            procsactual=loteEjecucion.pop(0)
            procesoEjecucion.append(procsactual)
            if inicio:
                print(f"{procsactual.operacion:11} |{procsactual.tiempo:6}    |{procsactual.id:6}    |{procsactual.transcurrido:6}     |  {procsactual.restante:5}")
            if not inicio:
                inicio=True
        elif procsactual.restante>=1:
            print(f"{procsactual.operacion:11} |{procsactual.tiempo:6}    |{procsactual.id:6}    |{procsactual.transcurrido:6}     |  {procsactual.restante:5}")
        print()
        print ("---------------------------------------------------------------------")
        print("                 Procesos terminados\n")
        print("    ID   |   Operación   |   Resultado   |   Lote")
        if procsactual.restante==0 and len(procesoEjecucion)>0:
            terminado=procesoEjecucion.pop(0)
            copialotes.pop(0)
            procesosTerminados.append(terminado)
            #siguiente=True
        for terminados in procesosTerminados:
            print(f"  {terminados.id:5}  | {terminados.operacion:13} | {terminados.resultado:8}      | {terminados.lote:4}")
        print()
        print ("---------------------------------------------------------------------")
        if len(loteEjecucion)==0 and len(procesoEjecucion)==0:
            break
        if p:
            print("Procesos en Pausa...")
            time.sleep(1)
            clearscreen()
            continue
        contador, procsactual.restante, procsactual.transcurrido=contar(contador,procsactual.restante,procsactual.transcurrido)
        
def main():
    global procesos
    global lote
    global loteEjecucion
    global procesoEjecucion
    global inicio
    inicio = False
    clearscreen()
    declararProcesos()
    while True:
        if len(procesos)>0:
            loteEjecucion.clear()
            procesoEjecucion.clear()
            mostrarProcesos()
            lote-=1
        elif len(procesos)==0:
            print("Lotes procesados, pulse ENTER para salir")
            print("\n")
            input()
            break
if __name__=='__main__':
    main()