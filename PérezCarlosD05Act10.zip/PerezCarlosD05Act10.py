import os
import time
import random
import keyboard

contenedor=["_"]*22
numeros=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
productor=False
consumidor=False
e=False

def clearscreen():
    os.system('cls' if os.name == 'nt' else 'clear')

def imprimirlista():
    for elemento in contenedor:
        print(elemento, end="  ")
    print("")
    for i in range(9):
        print(numeros[i], end="  ")
    for i in range(9, 22):
        print(numeros[i], end=" ")
    print("")


def on_key_press(tecla):
    global e
    if tecla.name == 'esc':
        e=True

def main():
    global productor
    global consumidor
    i=0
    j=0
    while True:
        num=random.randint(3,6)
        num2=random.randint(1,100)
        productor=False
        consumidor=False
        keyboard.on_press(on_key_press)
        if num2%2==0:
            productor=True
        else:
            consumidor=True
        if productor:
            if "_" in contenedor:
                for _ in range(num):
                    contenedor[i]="*"
                    if i+1!=22:
                        if contenedor[i+1]=="*":
                            break
                    i+=1
                    if i==22:
                        i=0
                print("Productor: Trabajando")
            else:
                print("Productor: Intentando trabajar")
            print("Consumidor: Dormido")
        if consumidor:
            print("Productor: Dormido")
            if "*" in contenedor:
                for _ in range(num):
                    contenedor[j]="_"
                    if j+1!=22:
                        if contenedor[j+1]=="_":
                            break
                    j+=1
                    if j==22:
                        j=0
                print("Consumidor: Trabajando")
            else:
                print("Consumidor: Intentando trabajar")
        
        imprimirlista()
        time.sleep(2)
        if e:
            exit()
        clearscreen()

if __name__=='__main__':
    main()